#include "stdafx.h"
#include "MechanismForm.h"

MechanismForm::MechanismForm(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

MechanismForm::~MechanismForm()
{}
