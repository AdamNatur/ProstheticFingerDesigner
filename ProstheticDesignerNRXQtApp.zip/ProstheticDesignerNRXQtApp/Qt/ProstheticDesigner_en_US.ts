<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>HelloQtChildClass</name>
    <message>
        <location filename="../../../source/repos/HelloQt/HelloQtChild.ui" line="14"/>
        <source>HelloQtChild</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../source/repos/HelloQt/HelloQtChild.ui" line="20"/>
        <source>Click me!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../source/repos/HelloQt/HelloQtChild.ui" line="27"/>
        <source>Click me too!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../source/repos/HelloQt/HelloQtChild.ui" line="34"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
